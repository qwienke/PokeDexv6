//
//  TypeChart.swift
//  PokedexV6
//
//  Created by Quinn Wienke on 8/28/23.
//

import SwiftUI

struct TypeChart: View {
    var body: some View {
        Image(uiImage: UIImage(named: "TypeChart")!)
            .interpolation(.none)
            .resizable()
            .frame(width: 390, height: 390)
            .offset(y: -190)    }
}

struct TypeChart_Previews: PreviewProvider {
    static var previews: some View {
        TypeChart()
    }
}
