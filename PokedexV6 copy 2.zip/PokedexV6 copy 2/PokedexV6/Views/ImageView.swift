///
//  ImaegView.swift
//  PokedexV6
//
//  Created by Quinn Wienke on 8/24/23.
//

import SwiftUI
import Kingfisher

struct ImageView: View {
    let pokemon: Pokemon
    
    var body: some View {
            KFImage(URL(string: pokemon.imageURL))
        
                .interpolation(.none)
                .resizable()
            .frame(width: 120, height: 120)
    }
    
    
    struct ImageView_Previews: PreviewProvider {
        static var previews: some View {
            ImageView(pokemon: Pokemon.example)
        }
    }
}
    /*
    KFImage(URL(string: pokemon.imageURL)) { phase in
        if let image = phase.image {
            image
                .resizable()
                .scaledToFit()
        } else if phase.error != nil {
            Text("Error loading image")
        } else {
            ProgressView()
        }
    }
    .frame(width: 100, height: 100)    }
     */
