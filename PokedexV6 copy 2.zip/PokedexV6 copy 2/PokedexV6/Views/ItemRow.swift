//
//  ItemRow.swift
//  PokedexV6
//
//  Created by Quinn Wienke on 8/23/23.
//

import SwiftUI

struct ItemRow: View {
   // @State private var pokemon = [Pokemon]()
    let pokemon: Pokemon
    
    var body: some View {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text(pokemon.name.capitalized)
                        .font(.title)
                    HStack {
                        Text(pokemon.type.capitalized)
                            .italic()
                        Circle()
                            .foregroundColor(pokemon.typeColor)
                            .frame(width: 10, height: 10)
                    }
                }
            }
        }
    }
    
    struct ItemRow_Previews: PreviewProvider {
        static var previews: some View {
            ItemRow(pokemon: Pokemon.example)
        }
    }

