//
//  TypesView.swift
//  PokedexV6
//
//  Created by Quinn Wienke on 8/28/23.
//
/*
import SwiftUI

struct TypesView: View {
    let type: PokemonType
    
    var body: some View {
        
        /*
         VStack {
         Text("doubleDamageFrom")
         //  ForEach(type.damageRelations.doubleDamageFrom) { doubleDamage in
         
         //Text(damageRelation.id.uuidString)
         }
         
         Text("doubleDamageTo")
         // ForEach(type.damageRelations.doubleDamageTo) { doubleDamage in
         
         //Text(damageRelation.id.uuidString)
         }
         }
         //        Text(type.damageRelations)
         */
        
        
        
        
        
        struct TypesView_Previews: PreviewProvider {
            static var previews: some View {
                TypesView(type: PokemonType.example)
            }
        }
    }
}
*/
