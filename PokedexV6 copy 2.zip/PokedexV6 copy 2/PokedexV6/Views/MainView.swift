//
//  MainView.swift
//  PokedexV6
//
//  Created by Quinn Wienke on 8/31/23.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        NavigationView {
            VStack {
                Button(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/) {
                    NavigationLink("PokeDex") {
                        ContentView() 
                    }
                    print("Button Tapped")
                }
            }
        }
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
