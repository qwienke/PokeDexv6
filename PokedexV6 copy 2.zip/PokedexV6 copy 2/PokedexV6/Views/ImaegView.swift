//
//  ImaegView.swift
//  PokedexV6
//
//  Created by Quinn Wienke on 8/24/23.
//

import SwiftUI

struct ImaegView: View {
    let pokemon: Pokemon
    
    var body: some View {
        AsyncImage(url: URL(string: pokemon.imageURL)) { phase in
            if let image = phase.image {
                image
                    .resizable()
                    .scaledToFit()
            } else if phase.error != nil {
                Text("Error loading image")
            } else {
                ProgressView()
            }
        }
        .frame(width: 100, height: 100)    }
}

struct ImaegView_Previews: PreviewProvider {
    static var previews: some View {
        ImaegView(pokemon: Pokemon.example)
    }
}
