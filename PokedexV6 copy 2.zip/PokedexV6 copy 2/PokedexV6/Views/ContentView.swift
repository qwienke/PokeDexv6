//
//  ContentView.swift
//  PokedexV6
//
//  Created by Quinn Wienke on 8/23/23.
//

import SwiftUI

struct ContentView: View {
    var pokemonModel = PokemonModel()
    @State private var pokemon = [Pokemon]()
    @State private var searchText = ""
    
    var body: some View {
        NavigationView {
            List(pokemon) { poke in
                HStack {
                    HStack {
                        ImageView(pokemon: poke)
                    }
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.black, lineWidth: 4))
                    .frame(width: 130, height: 130)
                    
                    NavigationLink {
                        DetailView(pokemon: poke)
                    } label: {
                        ItemRow(pokemon: poke)
                    }

                }
            }
            Text("Searching for \(searchText)")
                .navigationTitle("Searchable")
            .navigationTitle("Pokemon")
        }
        .searchable(text: $searchText)
        .onAppear() {
            async {
                pokemon = try! await pokemonModel.getPokemon()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
