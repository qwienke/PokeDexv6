//
//  DetailView.swift
//  PokedexV6
//
//  Created by Quinn Wienke on 8/24/23.
//

import SwiftUI

struct DetailView: View {
    let pokemon: Pokemon

    
    var body: some View {
        Text(pokemon.name)
        Text(pokemon.type)
        Text(pokemon.description)
        ImageView(pokemon: pokemon)
    }
    
    struct DetailView_Previews: PreviewProvider {
        static var previews: some View {
            DetailView(pokemon: Pokemon.example)
        }
    }
}

