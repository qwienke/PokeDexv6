//
//  PokedexV6App.swift
//  PokedexV6
//
//  Created by Quinn Wienke on 8/23/23.
//

import SwiftUI

@main
struct PokedexV6App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
