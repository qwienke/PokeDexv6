//
//  Types.swift
//  PokedexV6
//
//  Created by Quinn Wienke on 8/28/23.
//



import Foundation

enum HTTPMethod: String {
    case get = "GET"
    case put = "PUT"
    case post = "POST"
    case delete = "DELETE"
}


struct PokemonType: Identifiable, Decodable {
    let id: Int
    
    var name: String
    var damageRelations: DamageRelations
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        
        case damageRelations = "damage_relations"
        
    }
    struct DamageRelations: Identifiable, Decodable {
        let id = UUID()
        
        let doubleDamageFrom: [Damage]
        //let damageRelations: [DoubleDamageFrom]
        let doubleDamageTo: [Damage]
        let halfDamageTo: [Damage]
        let halfDamageFrom: [Damage]
        let noDamageFrom: [Damage]
        let noDamageTo: [Damage]
        
        enum CodingKeys: String, CodingKey {
            case id
            case doubleDamageFrom = "double_damage_from"
            //case damageRelations = "damageRelations"
            case doubleDamageTo = "double_damage_to"
            case halfDamageTo = "half_damage_to"
            case halfDamageFrom = "half_damage_from"
            case noDamageFrom = "no_damage_from"
            case noDamageTo = "no_damage_to"
            
            
        }
    }
   // static let example = PokemonType(name: "normal", damageRelations: DoubleDamageFrom)
}



struct Damage: Decodable {
    var name: String
    let url: String
    
  
}
struct DamageName: Decodable {
    let name: String
}



//API Request

class NetworkManager {
    static let shared = NetworkManager()
    
    let baseURL = URL(string: "https://pokeapi.co/api/v2/type")!
    var pokemon: PokemonType?
    
    
    func getPokemonType(with searchText: String) {
        let requestURL = baseURL.appendingPathComponent(searchText)
        
        var request = URLRequest(url: requestURL)
        request.httpMethod = HTTPMethod.get.rawValue
        
        URLSession.shared.dataTask(with: request) { (data, _, error) in
            if let error = error {
                print("Error fetching pokemon: \(error)")
                return
            }
            
            guard let data = data else { return }
            
            do {
                let pokemon = try JSONDecoder().decode(PokemonType.self, from: data)
                self.pokemon = pokemon
                print(pokemon.damageRelations.doubleDamageTo)
            } catch {
                print("Error decoding Pokemon: \(error)")
                return
            }
        }.resume()
    }
}
NetworkManager.shared.getPokemonType(with: "electric")

